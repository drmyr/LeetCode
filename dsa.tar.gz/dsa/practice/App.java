package dsa.practice;

import lombok.val;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import static java.util.Arrays.asList;
import static java.util.stream.Collectors.toList;

public class App {

    public static void main(String[] args) {
        System.out.println("#####################");
        val ref = new AllNodesKDistanceInABinaryTree2();
        System.out.println(ref.getClass().getSimpleName());
        ref.run();
        System.out.println("#####################");

    }
}

class AllTheWaysHome2 {
    public void run() {

    }

    public int maximumPath(int[][] matrix) {
        throw new UnsupportedOperationException();
    }
}

class AllNodesKDistanceInABinaryTree2 {
    public void run() {

    }

    public List<Integer> distanceK(TreeNode root, TreeNode target, int K) {
        final Map<TreeNode, TreeNode> parentLookup = new HashMap<>();
        dfs(root, parentLookup);

        final Queue<TreeNode> alpha = new ArrayDeque<>();
        final Queue<TreeNode> beta = new ArrayDeque<>();

        final Set<TreeNode> visited = new HashSet<>();
        visited.add(target);

        final Function<Queue<TreeNode>, Queue<TreeNode>> getInactiveQueue = (treeNode) -> treeNode.equals(alpha) ? beta : alpha;

        final BiConsumer<TreeNode, Queue<TreeNode>> addCurrentNodeToQueueIfNotAlreadyVisited = (currentNode, activeQueue) -> {
            if(!visited.contains(currentNode)) {
                visited.add(currentNode);
                activeQueue.offer(currentNode);
            }
        };

        alpha.offer(target);
        Queue<TreeNode> activeQueue = alpha;

        while(K-- > 1) {
            final Queue<TreeNode> inactiveQueue = getInactiveQueue.apply(activeQueue);
            while(!activeQueue.isEmpty()) {
                final TreeNode currentNode = activeQueue.poll();
                addCurrentNodeToQueueIfNotAlreadyVisited.accept(currentNode.left, activeQueue);
                addCurrentNodeToQueueIfNotAlreadyVisited.accept(currentNode.right, activeQueue);
                final TreeNode parent = parentLookup.get(currentNode);
                addCurrentNodeToQueueIfNotAlreadyVisited.accept(parent, activeQueue);
            }
            activeQueue = inactiveQueue;
        }
        return activeQueue.stream().map(node -> node.val).collect(Collectors.toList());
    }

    private void dfs(final TreeNode root, Map<TreeNode, TreeNode> parentLookup) {
        if(root != null) {
            parentLookup.put(root.left, root);
            parentLookup.put(root.right, root);
            dfs(root.left, parentLookup);
            dfs(root.right, parentLookup);
        }
    }
}
