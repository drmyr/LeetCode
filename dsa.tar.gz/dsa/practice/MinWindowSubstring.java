package dsa.practice;

import com.sun.source.tree.Tree;
import lombok.Data;
import lombok.Value;
import lombok.val;
import org.w3c.dom.ls.LSOutput;

import java.beans.Visibility;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.*;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.function.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static java.util.Arrays.*;
import static java.util.Collections.emptyList;
import static java.util.Collections.singletonList;
import static java.util.concurrent.CompletableFuture.completedFuture;
import static java.util.stream.Collectors.toList;

//https://leetcode.com/problems/minimum-window-substring/
public class MinWindowSubstring {

    public static void main(final String[] args) {

        char[][] map = {{'O', 'O', 'O', 'O'},
                {'D', 'O', 'D', 'O'},
                {'O', 'O', 'O', 'O'},
                {'X', 'D', 'D', 'O'}};


//        val cs = new CourseSchedule();
//
//        int[][] arg = {{2,0},{1,0},{3,1},{3,2},{1,3}};
//
//        boolean res = cs.canFinish(4, arg);
//

        val islands = new char[][]
                {{'1', '1', '1', '1', '0'},
                {'1', '1', '0', '1', '0'},
                {'1', '1', '0', '0', '0'},
                {'0', '0', '0', '0', '0'}};


//        val islands = new char[][]
//                {{'1','1','0','0','0'},
//                {'1','1','0','0','0'},
//                {'0','0','1','0','0'},
//                {'0','0','0','1','1'}};

//        val ci = new CountingClusters();
//
//        val res = ci.numIslands(islands);

//        final List<int[]> a = Arrays.asList(new int[] {3, 6}, new int[] {1, 2}, new int[] {2, 4});
//        final List<int[]> b = Arrays.asList(new int[]{1, 2});
//        final int target = 7; // [[2, 1]]

//        List<int[]> a = Arrays.asList(new int[] {1, 3}, new int[] {2, 5}, new int[] {3, 7}, new int[] {4, 10});
//        List<int[]> b = Arrays.asList(new int[] {1, 2}, new int[] {2, 3}, new int[] {3, 4}, new int[] {4, 5});
//        int target = 10; //[[2, 4], [3, 2]]

//        List<int[]> a = Arrays.asList(new int[] {1, 8}, new int[] {2, 7}, new int[] {3, 14});
//        List<int[]> b = Arrays.asList(new int[] {1, 5}, new int[] {2, 10}, new int[] {3, 14});
//        int target = 20; // [[3, 1]]

//        List<int[]> a = Arrays.asList(new int[]{1, 8}, new int[] {2, 15}, new int[] {3, 9 });
//        List<int[]> b = Arrays.asList(new int[]{1, 8}, new int[] {2, 11}, new int[] {3, 12});
//        int target = 20; // [[1, 3], [3, 2]]

//        final OptimalUtilization ou = new OptimalUtilization();
//        final List<int[]> res = ou.solution(a, b, target);


//        char[][] treasureMapTwo =
//                {{'S', 'O', 'O', 'S', 'S'},
//                {'D', 'O', 'D', 'O', 'D'},
//                {'O', 'O', 'O', 'O', 'X'},
//                {'X', 'D', 'D', 'O', 'O'},
//                {'X', 'D', 'D', 'D', 'O'}};
//
//        TreasureIslandTwo ttwo = new TreasureIslandTwo();
//
//        val res = ttwo.shortestPath(treasureMapTwo);

//        val nums = asList(1, 10, 25, 35, 60);
//        int target = 90;

//        val nums = asList(20, 50, 40, 25, 30, 10);
//        int target = 90;
//
//        val find = new FindPairWithGivenSum();
//
//        val res = find.findPair(nums, 90);
//
//        System.out.println(res);

//        val one = new TreeNode(1);
//        val two = new TreeNode(2);
//        val four = new TreeNode(4);
//        four.left = one;
//        four.right = two;
//        val five = new TreeNode(5);
//        val three = new TreeNode(3);
//        three.left = four;
//        three.right = five;

//        val zero = new TreeNode(0);
//        val one = new TreeNode(1);
//        val two = new TreeNode(2);
//        two.left = zero;
//        val four = new TreeNode(4);
//        four.left = one;
//        four.right = two;
//        val five = new TreeNode(5);
//        val three = new TreeNode(3);
//        three.left = four;
//        three.right = five;
//
//        val oneT = new TreeNode(1);
//        val twoT = new TreeNode(2);
//        val fourT = new TreeNode(4);
//        fourT.left = oneT;
//        fourT.right = twoT;
//
//        val st = new SubtreeOfAnotherTree();
//
//        val res = st.isSubtree(three, fourT);
//
//        System.out.println(res);

//        List<List<Integer>> a = asList(asList(1, 2), asList(1, 3), asList(3, 4), asList(1, 4), asList(4, 5));
//        int n = 5; // [[1, 2], [4, 5]]

//        List<List<Integer>> a = asList(asList(1, 2), asList(1, 3), asList(2, 3), asList(2, 4), asList(2, 5), asList(4, 6), asList(5, 6));
//        int n = 6; // []

//        List<List<Integer>> a = asList(asList(1, 2), asList(1, 3), asList(2, 3), asList(3, 4), asList(3, 6), asList(4, 5), asList(6, 7), asList(6, 9), asList(7, 8), asList(8, 9));
//        int[][] aa = {{1, 2}, {1, 3}, {2, 3}, {3, 4}, {3, 6}, {4, 5}, {6, 7}, {6, 9}, {7, 8}, {8, 9}};
//        int n = 9; //[[3, 4], [3, 6], [4, 5]]
//
//
//
//        val cc = new CriticalEdges();
//
//        val res = cc.criticalConnections(n, a);
//
//        System.out.println(res);
//
//        val cn = new CriticalNodes();
//        val rescn = cn.findCriticalNodesInGraph(aa);
//
//        System.out.println(rescn);

//        val waysHome = new int[][] {{1, 2, 3}, {4, 5, 1}};
//
//        val wh = new AllTheWaysHome();
//
//        val res = wh.maximumPath(waysHome);
//
//        System.out.println(res);

//        int k = 2;
//        String[] keywords = {"anacell", "cetracular", "betacellular"};
//        String[] reviews = {
//        "Anacell provides the best services in the city",
//                "betacellular has awesome services",
//                "Best services provided by anacell, everyone should use anacell"};
//

//        int k = 2;
//        String[] keywords = {"anacell", "betacellular", "cetracular", "deltacellular", "eurocell"};
//        String[] reviews = {
//          "I love anacell Best services; Best services provided by anacell",
//                "betacellular has great services",
//                "deltacellular provides much better services than betacellular",
//                "cetracular is worse than anacell",
//                "Betacellular is better than deltacellular."};
//
//        val topk = new TopKFrequentlyMentionedKeywords();
//
//        val res = topk.topElement(keywords, reviews, k);
//
//        System.out.println(res);

//        String[] products = {"mobile","mouse","moneypot","monitor","mousepad"};
//        String searchWord = "mouse";

//        String[] products = {"havana"};
//        String searchWord = "tatiana";

//        String[] products = {"bags","baggage","banner","box","cloths"};
//        String searchWord = "bags";

//        val ps = new ProductSuggestions();
//
//        val res = ps.suggestedProducts(products, searchWord);
//
//        System.out.println(res);

        val ref = new Palindrome();
        System.out.println("###########################");
        System.out.println(ref.getClass().getSimpleName());
        ref.run();
        System.out.println("%%%%%%%%%%%%%%%%%%%%%%%");

    }
}

class Palindrome {

    public void run() {
        assert isPalindrome("racecar");
        assert isPalindrome("bloggolb");
        assert !isPalindrome("hellothere");
    }

    boolean isPalindrome(final String input) {
       int left = 0, right = input.length() - 1;
       while(left < right) {
           if(input.charAt(left) == input.charAt(right)) {
               left++; right--;
           } else {
               return false;
           }
       }
       return true;
    }
}

// https://www.youtube.com/watch?v=nYFd7VHKyWQ
class PrintAllPermutations {

    public void run() {
        val in = "abc";
        val res = permutations(in.chars().mapToObj(c -> (char)c).collect(toList()));
        res.forEach(System.out::println);
    }

    public void printAllPermut(final String src) {
        class Recurse {
            private void printRec(final String drain, final String source) {
                if(source.length() == 0) {
                    System.out.println(drain);
                } else {
                    for(int i = 0; i < source.length(); i++) {
                        printRec(drain + source.charAt(i), source.substring(0, i) + source.substring(i + 1, source.length() - 1));
                    }
                }
            }
        }
        new Recurse().printRec("", src);
    }

    // https://stackoverflow.com/questions/2799078/permutation-algorithm-without-recursion-java
    class PermUtil <T> {
        private T[] arr;
        private int[] permSwappings;

        public PermUtil(T[] arr) {
            this(arr,arr.length);
        }

        public PermUtil(T[] arr, int permSize) {
            this.arr = arr.clone();
            this.permSwappings = new int[permSize];
            for(int i = 0;i < permSwappings.length;i++)
                permSwappings[i] = i;
        }

        public T[] next() {
            if (arr == null)
                return null;

            T[] res = Arrays.copyOf(arr, permSwappings.length);
            //Prepare next
            int i = permSwappings.length-1;
            while (i >= 0 && permSwappings[i] == arr.length - 1) {
                swap(i, permSwappings[i]); //Undo the swap represented by permSwappings[i]
                permSwappings[i] = i;
                i--;
            }

            if (i < 0)
                arr = null;
            else {
                int prev = permSwappings[i];
                swap(i, prev);
                int next = prev + 1;
                permSwappings[i] = next;
                swap(i, next);
            }

            return res;
        }

        private void swap(int i, int j) {
            T tmp = arr[i];
            arr[i] = arr[j];
            arr[j] = tmp;
        }
    }

    private static void printPermutationsIterative(String string){
        int [] factorials = new int[string.length()+1];
        factorials[0] = 1;
        for (int i = 1; i<=string.length();i++) {
            factorials[i] = factorials[i-1] * i;
        }

        for (int i = 0; i < factorials[string.length()]; i++) {
            String onePermutation="";
            String temp = string;
            int positionCode = i;
            for (int position = string.length(); position > 0 ;position--){
                int selected = positionCode / factorials[position-1];
                onePermutation += temp.charAt(selected);
                positionCode = positionCode % factorials[position-1];
                temp = temp.substring(0,selected) + temp.substring(selected+1);
            }
            System.out.println(onePermutation);
        }
    }

    public static <T> List<List<T>> permutations(List<T> src){

        if(src.isEmpty()) return emptyList();

        List<List<T>> permutations = new ArrayList<>();

        // We add the first element
        permutations.add(new ArrayList<T>(singletonList(src.get(0))));

        // Then, for all elements e in es (except from the first)
        for (int i = 1, len = src.size(); i < len; i++) {
            T elem = src.get(i);
            System.out.println("$" + elem);

            // We take remove each list l from 'permutations'
            for (int j = permutations.size() - 1; j >= 0; j--) {
                List<T> aResult = permutations.remove(j);
                System.out.println("#" + aResult);

                // And adds a copy of l, with e inserted at index k for each position k in l
                for (int k = aResult.size(); k >= 0; k--) {
                    ArrayList<T> ts2 = new ArrayList<>(aResult);
                    ts2.add(k, elem);
                    permutations.add(ts2);
                    permutations.forEach(r -> System.out.println("%" + r));
                }
            }
        }
        return permutations;
    }

}

@Data
class ListNode {
    final int val;
    ListNode next;

    ListNode(final int val) {
        this.val = val;
    }
}

class MergeKSortedLinkedLists {
    public ListNode mergeKLists(ListNode[] lists) {
        final PriorityQueue<ListNode> queue = new PriorityQueue<>(Comparator.comparingInt(ListNode::getVal));
        queue.addAll(asList(lists));

        final ListNode head = new ListNode(0);

        ListNode current = head;
        while(!queue.isEmpty()) {
            current.next = queue.poll();
            current = current.next;
            if(current.next != null) queue.add(current.next);
        }

        return head.next;
    }
}

class TrappingRainWater {
    public void run() {
        int[] a = {0,1,0,2,1,0,1,3,2,1,2,1};

        System.out.println(amountOfRain(a));
    }

    public int amountOfRain(int[] heights) {
        final int[] fromLeft = new int[heights.length];
        final int[] fromRight = new int[heights.length];

        fromLeft[0] = heights[0];
        for(int i = 1; i < heights.length; i++) {
            fromLeft[i] = Math.max(heights[i], fromLeft[i - 1]);
        }

        fromRight[heights.length - 1] = heights[heights.length - 1];
        for(int i = heights.length - 2; i >= 0; i--) {
            fromRight[i] = Math.max(heights[i], fromRight[i + 1]);
        }

        int ans = 0;
        for(int i = 1; i < heights.length - 2; i++) {
            ans += Math.min(fromLeft[i], fromRight[i]) - heights[i];
        }

        return ans;
    }
}

class DiameterOfTree {
    public void run() {
        val four = new TreeNode(4);
        val five = new TreeNode(5);
        val two = new TreeNode(2, four, five);

        val three = new TreeNode(3);
        val one = new TreeNode(1, two, three);

        System.out.println(diameterOfTreeImperative(one));
    }

    public int diameterOfTreeImperative(TreeNode root) {
        final Stack<TreeNode> stack = new Stack<>();
        final Map<TreeNode, Integer> heightOfNode = new HashMap<>();
        final int heightOfActiveNode = 1;

        int max = 0;

        TreeNode ref = root;
        while(!stack.isEmpty() || ref != null) {
            while(ref != null) {
                stack.push(ref);
                ref = ref.left;
            }
            ref = stack.pop();

            int myLeft = heightOfNode.getOrDefault(ref.left, 0);
            int myRight = heightOfNode.getOrDefault(ref.right, 0);

            max = Math.max(max, myLeft + myRight + heightOfActiveNode);

            heightOfNode.put(ref, Math.max(myLeft, myRight) + heightOfActiveNode);

            ref = ref.right;
        }

        return max;
    }

    public int findDiameter(TreeNode root) {
        int[] max = {0};
        class Recurse {
            private int depth(TreeNode current) {
                if(current == null) return 0;
                int left = depth(current.left);
                int right = depth(current.right);
                max[0] = Math.max(max[0], left + right + 1);
                return Math.max(left, right) + 1;
            }
        }
        new Recurse().depth(root);
        return max[0];
    }
}

// https://github.com/grandyang/leetcode/issues/265
// https://www.youtube.com/watch?v=AbKBVTC54ZM
//
class PaintHouseII {
    public void run() {
        System.out.println("PaintHouseII");

        val test1 = new int[][] {
            {144, 2, 11}, {11, 14, 5}, {14, 3, 10}
        };
        val test2 = new int[][] {
            {1, 2, 3}, {1, 4, 6}
        };

        val res1 = minCostII(test1); assert res1 == 10;
        val res2 = minCostII(test2); assert res2 == 3;
    }

    public int minCostII(final int[][] costs) {

        final int[][] clone = costs.clone();
        
        final Function<Integer, int[]> houseAbove = (final Integer index) -> clone[index - 1];

        final int red = 0;
        final int blue = 1;
        final int green = 2;

        for(int i = 1; i < clone.length; i++) {
            clone[i][red] += Math.min(houseAbove.apply(i)[blue], houseAbove.apply(i)[green]);
            clone[i][blue] += Math.min(houseAbove.apply(i)[red], houseAbove.apply(i)[green]);
            clone[i][green] += Math.min(houseAbove.apply(i)[red], houseAbove.apply(i)[blue]);
        }

        final int[] lastRow = clone[clone.length - 1];
        return Math.min(lastRow[red], Math.min(lastRow[blue], lastRow[green]));
    }
}

//https://leetcode.com/discuss/interview-question/algorithms/124783/coursera-online-assessment-min-discount/126008
//https://leetcode.com/problems/daily-temperatures/solution/
class MinDiscount { //NearestSmallestElement

    public void run() {
        val res = minTemps(new int[] {73, 74, 75, 71, 69, 72, 76, 73});
        assert Arrays.equals(res, new int[] {1, 1, 4, 2, 1, 1, 0, 0});
    }

//    public int[] minDiscount(int[] discounts) {
//        int[] ans = new int[discounts.length];
//
//        Stack<>
//    }

    // For example, given the list of temperatures T = [73, 74, 75, 71, 69, 72, 76, 73], your output should be [1, 1, 4, 2, 1, 1, 0, 0].
    public int[] minTemps(final int[] temps) {

        class TempAndIndex {
            final int temp;
            final int index;

            private TempAndIndex(final int temp, final int index) {
                this.temp = temp;
                this.index = index;
            }
        }

        final int[] ans = new int[temps.length];
        final Stack<TempAndIndex> stack = new Stack<>();

        for(int i = 0; i < temps.length - 1; i++) {
            while(!stack.isEmpty() && stack.peek().temp <= temps[i]) {
                final TempAndIndex tempAndIndex = stack.pop();
                ans[tempAndIndex.index] = i - tempAndIndex.index;
            }
            if(temps[i] < temps[i + 1]) {
                ans[i]++;
            } else {
                stack.push(new TempAndIndex(temps[i], i));
            }
        }

        return ans;
    }
}

class GreedyScheduling {

    public void run() {
        System.out.println("GreedyScheduling");
        int[][] times1 = {
            {1, 2}, {3, 2}, {3, 1}, {5, 2}, {7, 1}
        };
        int[][] times2 = {
            {1, 2}, {3, 2}, {3, 2}, {4, 3}, {7, 1}
        };
        int[][] times3 = {
            {1, 4}, {3, 3}, {4, 3}, {6, 2}
        };
        val res1 = minMeetingRooms(times1); assert res1 == 4;
        val res2 = minMeetingRooms(times2); assert res2 == 3;
        val res3 = minMeetingRooms(times3); assert res3 == 2;
    }

    public int minMeetingRooms(int[][] intervals) {
        Arrays.sort(intervals, Comparator.comparingInt((int[] arr) -> arr[0]));

        int scheduledMeetings = 1;

        int currentMeetingEndTime = intervals[0][0] + intervals[0][1];
        for(int i = 1; i < intervals.length; i++) {
            if(currentMeetingEndTime <= intervals[i][0]) {
                scheduledMeetings++;
                currentMeetingEndTime = intervals[i][0] + intervals[i][1];
            }
        }

        return scheduledMeetings;
    }
}

class MininumNumberCoinChange {
    public void run() {
        System.out.println("MininumNumberCoinChange");
        val res = getMinNumberOfCoins(new int[] {5,6,1,8}, 11);
        val res2 = getMinNumberOfCoins(new int[] {1, 2, 5}, 11);
        assert res2 == 3;
        System.out.println(res);
    }

    public int getMinNumberOfCoins(final int[] coins, final int total) {
        Arrays.sort(coins);

        final int addColumn = total + 1;

        final int[][] memoization = new int[coins.length][addColumn];

        final BiFunction<Integer, Integer, Boolean> coinTooBig =
            (final Integer coin, final Integer targetValue) -> coin > targetValue;

        for(int r = 0; r < coins.length; r++) {
            for(int c = 1; c < addColumn; c++) {
                if(r == 0) {
                    memoization[r][c] = coinTooBig.apply(coins[r], c) ? 0 : c;
                } else {
                    if(coinTooBig.apply(coins[r], c)) {
                        memoization[r][c] = memoization[r - 1][c];
                    } else {
                        memoization[r][c] = Math.min(memoization[r - 1][c], memoization[r][c - coins[r]] + 1);
                    }
                }
            }
        }
        return memoization[coins.length - 1][addColumn - 1];
    }

    public int getMinNumberOfCoinsSmaller(int[] coins, int total) {
        Arrays.sort(coins);

        int addColumn = total + 1;

        int[] memoization = new int[addColumn];

        for(int r = 0; r < coins.length; r++) {
            for(int c = 1; c < addColumn; c++) {
                if(r == 0) {
                    memoization[c] = coins[r] > c ? 0 : c;
                } else {
                    if(coins[r] < c) {
                        memoization[c] = Math.min(memoization[c], memoization[c - coins[r]] + 1);
                    }
                }
            }
        }
        return memoization[addColumn - 1];
    }
}

class AllNodesKDistanceInABinaryTree {

    public void run() {
        val seven = new TreeNode(7);
        val four = new TreeNode(4);
        val six = new TreeNode(6);
        val two = new TreeNode(2, seven, four);
        val five = new TreeNode(5, six, two);

        val zero = new TreeNode(0);
        val eight = new TreeNode(8);
        val one = new TreeNode(1, zero, eight);

        val three = new TreeNode(3, five, one);

        System.out.println(distanceK(three, five, 2));
    }

    public List<Integer> distanceK(TreeNode root, TreeNode target, int K) {
        final Map<TreeNode, TreeNode> parentLookup = new HashMap<>();
        dfs(root, parentLookup);

        final Queue<TreeNode> alpha = new LinkedList<>();
        final Queue<TreeNode> beta = new LinkedList<>();
        alpha.offer(target);

        final Set<TreeNode> visited = new HashSet<>();
        visited.add(target);

        final Function<Queue<TreeNode>, Queue<TreeNode>> getInactive = (treeNode) -> treeNode.equals(alpha) ? beta : alpha;

        final BiConsumer<TreeNode, Queue<TreeNode>> addToInactiveQueueIfNotAlreadyVisited = (node, queue) -> {
            if(!visited.contains(node)) {
                visited.add(node);
                queue.offer(node);
            }
        };

        int dist = 0;
        Queue<TreeNode> activeQueue = alpha;

        while(dist < K) {
            final Queue<TreeNode> inactiveQueue = getInactive.apply(activeQueue);
            while(!activeQueue.isEmpty()) {
                final TreeNode next = activeQueue.poll();
                addToInactiveQueueIfNotAlreadyVisited.accept(next.left, inactiveQueue);
                addToInactiveQueueIfNotAlreadyVisited.accept(next.right, inactiveQueue);
                final TreeNode parent = parentLookup.get(next);
                addToInactiveQueueIfNotAlreadyVisited.accept(parent, inactiveQueue);
            }
            activeQueue = inactiveQueue;
            dist++;
        }
        return activeQueue.stream().filter(Objects::nonNull).map(TreeNode::getVal).collect(Collectors.toUnmodifiableList());
    }

    private void dfs(TreeNode root, Map<TreeNode, TreeNode> lookup) {
        if(root != null) {
            TreeNode left = root.left;
            TreeNode right = root.right;
            lookup.put(left, root);
            lookup.put(right, root);
            dfs(left, lookup);
            dfs(right, lookup);
        }
    }

}

class ValidBST {
    public boolean isValidBST(TreeNode root) {
        final Stack<TreeNode> stack = new Stack<>();
        double inorder = - Double.MAX_VALUE;

        while (!stack.isEmpty() || root != null) {
            while (root != null) {
                stack.push(root);
                root = root.left;
            }
            root = stack.pop();
            // If next element in inorder traversal
            // is smaller than the previous one
            // that's not BST.
            if (root.val <= inorder) return false;
            inorder = root.val;
            root = root.right;
        }
        return true;
    }
}

class LRUCache {

    final int capacity;
    final Map<Integer, Node> map;
    Node head;
    Node tail;

    public LRUCache(int capacity) {
        this.map = new HashMap<>();
        this.capacity = capacity;

        this.head = new Node(-1, -1);
        this.tail = new Node(-2, -2);
        head.prev = null;
        head.next = tail;
        tail.prev = head;
        tail.next = null;
    }

    public int get(int key) {
        Node node = map.get(key);

        if(node == null) return -1;

        node.leaveLine();

        head = node.becomeLeader(head);

        return node.value;
    }

    public void put(int key, int value) {
        if(map.containsKey(key)) {
           Node existing = map.get(key);
           existing.value = value;
           existing.leaveLine();
           head = existing.becomeLeader(head);
           return;
        }

        if(map.size() == capacity) {
            map.remove(tail.id);
            Node newTail = tail.prev;
            tail.leaveLine();
            tail = newTail;
        }

        Node newNode = new Node(key, value);
        map.put(key, newNode);
        head = newNode.becomeLeader(head);
    }

    static class Node {
        final int id;
        int value;
        Node prev;
        Node next;

        Node(int id) {
            this.id = id;
        }

        Node(int id, int value) {
            this(id);
            this.value = value;
        }

        void leaveLine() {
            if(prev != null) prev.next = next;
            if(next != null) next.prev = prev;
        }

        Node becomeLeader(Node currentHead) {
            next = currentHead;
            currentHead.prev = this;
            prev = null;
            return this;
        }
    }
}

class LCA {
    public void run() {

        val nine = new TreeNode(9);
        val five = new TreeNode(5);
        val eleven = new TreeNode(11, nine, five);
        val two = new TreeNode(2);
        val six = new TreeNode(6, two, eleven);

        val seven = new TreeNode(7);
        val thirteen = new TreeNode(13, seven, null);
        val eight = new TreeNode(8, null, thirteen);

        val three = new TreeNode(3, six, eight);

        System.out.println("#######################" + lowestCommonAncestor(three, two, five));

    }

    public int lowestCommonAncestor(final TreeNode root, TreeNode p, TreeNode q) {
        // Stack for tree traversal
        final Deque<TreeNode> stack = new ArrayDeque<>();
        stack.push(root);
        // HashMap for parent pointers
        final Map<TreeNode, TreeNode> parent = new HashMap<>();
        parent.put(root, null);
        // Iterate until we find both the nodes p and q
        while (!parent.containsKey(p) || !parent.containsKey(q)) {
            final TreeNode node = stack.pop();
            // While traversing the tree, keep saving the parent pointers.
            if (node.left != null) {
                parent.put(node.left, node);
                stack.push(node.left);
            }
            if (node.right != null) {
                parent.put(node.right, node);
                stack.push(node.right);
            }
        }
        // Ancestors set() for node p.
        final List<TreeNode> ancestors = new ArrayList<>();
        // Process all ancestors for node p using parent pointers.
        while (p != null) {
            ancestors.add(p);
            p = parent.get(p);
        }
        // The first ancestor of q which appears in
        // p's ancestor set() is their lowest common ancestor.
        int counter = 0;
        while (!ancestors.contains(q)) {
            q = parent.get(q);
            counter++;
        }

        return ancestors.indexOf(q) + counter;
    }

    private TreeNode findLCA(TreeNode current, TreeNode n1, TreeNode n2) {

        if(current == null) return null;

        if(current.val == n1.val || current.val == n2.val) return current;

        TreeNode left = findLCA(current.left, n1, n2);
        TreeNode right = findLCA(current.right, n1, n2);

        if(left != null && right != null) return current;

        if(left == null && right == null) return null;

        return left != null ? left : right;
    }

    private int findMinDist(TreeNode lca, TreeNode n1, TreeNode n2) {
        if(lca == null) return 0;

        if(lca.val == n1.val || lca.val == n2.val) return 1;

        int left = findMinDist(lca.left, n1, n2);

        int right = findMinDist(lca.right, n1, n2);

        if(left > 0 && right == 0) return left + 1;

        if(right > 0 && left == 0) return right + 1;

        return left + right;
    }

    public int findMinimumDistance(TreeNode root, TreeNode n1, TreeNode n2) {

        TreeNode lca = findLCA(root, n1, n2);

        return findMinDist(lca, n1, n2);

    }
}

class FindIn2D_SortedMatrix {

    public void run() {
        int[][] m = new int[][] {{1,2,3}, {4,5,6}, {7,8,9}};

        System.out.println(contains(m, 4));
        System.out.println(contains(m, 10));
        System.out.println(contains(m, 7));
        System.out.println(contains(m, 12));
    }

    public boolean contains(int[][] arr, int t) {
        int[] spot = new int[] {0, arr[0].length - 1};

        Function<int[], Boolean> inBounds = coord -> {
            int r = coord[0];
            int c = coord[1];
            return r >= 0 && r < arr.length && c >= 0 && c < arr[0].length;
        };

        while(inBounds.apply(spot)) {
            int r = spot[0];
            int c = spot[1];

            if(arr[r][c] < t)
                spot[0] = r + 1;
            if(arr[r][c] > t)
                spot[1] = c - 1;
            if(arr[r][c] == t)
                return true;
        }
        return false;
    }
}

class Kth_estElement {

    public void run() {
        int[] vals = {3,2,1,5,6,4};

        val res = getKthLargestElement(vals, 2);

        System.out.println(res);
    }

    public int getKthLargestElement(int[] arr, int k) {
        final PriorityQueue<Integer> queue = new PriorityQueue<Integer>(Comparator.naturalOrder());

        for(int val : arr) queue.add(val);

        while(k-- > 1) queue.poll();

        return queue.poll();
    }
}

class K_MostFrequent {
    public List<Integer> kMostFrequentElements(final int[] arr, final int k) {
        final Map<Integer, Integer> freq = new HashMap<>();
        final List<List<Integer>> bucket = new ArrayList<>(arr.length);
        for (int value : arr) {
            freq.merge(value, 1, Integer::sum);
        }

        freq.forEach((raw, freqCount) -> {
            final List<Integer> existing = bucket.get(freqCount);
            if(existing != null) {
                existing.add(raw);
            } else {
                final List<Integer> newList = new ArrayList<>();
                newList.add(raw);
                bucket.add(freqCount, newList);
            }
        });

        final List<Integer> result = new ArrayList<>();
        for(int i = bucket.size() - 1; i > 0 && result.size() < k; i--) {
            result.addAll(bucket.get(i));
        }
        return result;
    }
}

class MergeIntervals {

    public void run() {
        int[][] a = {{1,3},{2,6},{8,10},{15,18}};
        int[][] b = {{1,4},{4,5}};

        for(int[][] z : asList(a, b)) {
            int[][] res = merge(z);
            for(int[] y : res) {
                System.out.print(Arrays.toString(y));
            }
            System.out.println();
        }
    }
    public int[][] merge(int[][] intervals) {

        Arrays.sort(intervals, Comparator.comparingInt(arr -> arr[0]));

        List<int[]> mergedIntervals = new ArrayList<>();

        int[] currentInterval = intervals[0];

        mergedIntervals.add(currentInterval);

        for(int[] interval : intervals) {
            if(currentInterval[1] >= interval[0]) {
                int max = Math.max(currentInterval[1], interval[1]);
                currentInterval[1] = max;
            } else {
                currentInterval = interval;
                mergedIntervals.add(currentInterval);
            }
        }

        return mergedIntervals.toArray(new int[][]{});
    }
}

class SearchInRotatedSortedArray {
    public int search(int[] nums, int target) {
        if(target < 0 || nums.length < 1) return -1;

        // find the pivot

        int left = 0;
        int right = nums.length - 1;

        while(left < right) {
            int mid = left + ((right - left) / 2);
            if(nums[mid] > nums[right]) {
                left = mid + 1;
            } else {
                right = mid;
            }
        }

        // when we break, left is now pointing at the smallest element in the array

        // is element >= pivot and less than end
        // or
        // is pivot >= start and less than pivot

        // left stays where it is, right goes back to end of array
        if(target >= nums[left] && target <= nums[nums.length - 1]) {
            right = nums.length - 1;
        } else {
            // right now needs to point at the value to the left of the pivot point
            // that value should be the largest element in the array
            right = left - 1;
            left = 0;
        }

        while(left <= right) {
            int mid = left + ((right - left) / 2);
            if(nums[mid] == target) {
                return mid;
            } else if(nums[mid] < target) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }

        return -1;


        // then binary search
    }
}

class RabbitAndHareCycleDetection {

    public void run() {
        val t = hasCycle(new int[] {1,2,1,3,8}); assert t;
        System.out.println("good");

//        val f = hasCycle(new int[] {});
//        assert !f;
    }

    public boolean hasCycle(final int[] arr) {
        int r = 0;
        int h = 0;

        final Function<Integer, Boolean> inBounds = (final Integer index) -> index >= 0 && index < arr.length;

        while(true) {

            r = arr[r];

            if(r == h) return true;

            if(!inBounds.apply(r) || !inBounds.apply(h)) return false;

            h = arr[h];

            if(r == h) return true;

        }

//        while(true) {
//            if(!inBounds.apply(r) || !inBounds.apply(h)) return false;
//
//            r = arr[r];
//
//            if(r == h) return true;
//
//            if(!inBounds.apply(r)) return false;
//
//            h = arr[h];
//
//            if(r == h) return true;
//
//            // if(!inBounds.apply(h)) return false;
//
//        }
    }
}

class IsTheKingThreatened {

    public boolean isTheKingThreatened(int Qr, int Qc, int Kr, int Kc) {
        return Kr == Qr || Kc == Qc || (Qr - Qc) == (Kr - Kc) || (Qr + Qc) == (Kr + Kc);
    }

}

class PrintLineAfterEachTreeLevel {
    public void levelOrderPrinter(final TreeNode treeNode) {
        final Deque<TreeNode> alpha = new ArrayDeque<>();
        final Deque<TreeNode> beta = new ArrayDeque<>();

        alpha.offer(treeNode);

        Function<Deque<TreeNode>, Deque<TreeNode>> getOther = current -> current.equals(alpha) ? beta : alpha;

        Deque<TreeNode> activeQueue = alpha;
        while(!activeQueue.isEmpty()) {
            Deque<TreeNode> inactiveQueue = getOther.apply(activeQueue);
            TreeNode currentNode = alpha.poll();
            System.out.print(currentNode.val);
            for(TreeNode child : currentNode.getChildren()) {
                inactiveQueue.offer(child);
            }
            if(activeQueue.isEmpty()) {
                System.out.print("\n");
                activeQueue = inactiveQueue;
            }
        }
    }
}

class NQueens {

    public List<int[]> findNQueenCoords(final int n) {
        if(n == 1) return singletonList(new int[] {0, 0});
        if(n == 2 || n == 3) return emptyList();

        class Queen {
            final int r;
            int c = -1;

            Queen(final int id) {
                this.r = id;
            }

            void advance() {
                if((c + 1) < n) {
                    c++;
                }
            }

            boolean hasAnotherMove() {
                return c < (n - 1);
            }

            void removeFromBoard() {
                this.c = -1;
            }

            boolean isOnTheBoard() {
                return c > 0 && c < (n - 1);
            }

            public boolean canBeAttacked(final List<Queen> others) {
                for(final Queen other : others) {
                    if(r == other.r || !other.isOnTheBoard()) continue;
                    if(other.c == c || (r - c) == (other.r - other.c) || (r + c) == (other.r + other.c)) return true;
                }
                return false;
            }
        }

        final List<Queen> queens = new ArrayList<>();
        for(int i = 0; i < n; i++) queens.add(new Queen(i));

        int queenId = 0;

        Queen currentQueen = queens.get(queenId);
        while(true) {
            currentQueen.advance();
            if(!currentQueen.canBeAttacked(queens)) {
                if(queenId == (n - 1)) return queens.stream().map(queen -> new int[] {queen.r, queen.c}).collect(toList());
                currentQueen = queens.get(++queenId);
            } else {
                while(!currentQueen.hasAnotherMove()) {
                    currentQueen.removeFromBoard();
                    currentQueen = queens.get(--queenId);
                }
            }
        }
    }
}

class LongestConsecutiveSequence {

    public int longestConsecutive(int[] nums) {

        final Set<Integer> numsSet = new HashSet<>();
        for(int i : nums) numsSet.add(i);

        int longest = 0;

        for(int num : numsSet) {
            if(!numsSet.contains(num - 1)) {
                int curr = num;
                int localStreak = 1;

                while(numsSet.contains(curr + 1)) {
                    curr++;
                    localStreak++;
                }

                longest = Math.max(localStreak, longest);
            }
        }
        return longest;
    }
}

class AreaUnderHistogram {

    public void runSingle() {
        int res = areaUnderHistogramUsingStack(new int[] {1,2,5,6,4});

        System.out.println(res);
    }

    public void run() {
        //final int[][] a = {{2,3,1,4,5,4,2}, {}};
        final int[][] a = {{3, 1, 6, 4, 3, 2, 1, 5}, {9}};
        final int[][] b = {{6, 2, 5, 4, 5, 1, 6}, {12}};
        final int[][] c = {{2, 1, 5, 6, 2, 3}, {10}};
        final int[][] d = {{1, 2, 3, 4, 5, 3, 3, 2}, {15}};

        for(int[][] z : asList(a, b, c, d)) {
            final int res = areaUnderHistogramUsingStack(z[0]);

            System.out.println(res);

            assert res == z[1][0];
        }
    }

    public int areaUnderHistogramUsingStack(final int[] columns) {
        //final Deque<Integer> stack = new LinkedList<>();
        final Stack<Integer> stackOfIndexes = new Stack<>();

        final Function<Integer, Boolean> isHistogramIsStillGoingUp = (index) -> {
            return stackOfIndexes.isEmpty() || columns[stackOfIndexes.peek()] < columns[index];
        };

        final Function<Integer, Boolean> isHistogramFlatOrFalling = (index) -> {
            return !stackOfIndexes.isEmpty() && columns[index] <= columns[stackOfIndexes.peek()];
        };

        int max = 0;
        int index = 0;

        while(index < columns.length) {

            if(!isHistogramIsStillGoingUp.apply(index)) {
                while(isHistogramFlatOrFalling.apply(index)) {
                    int top = stackOfIndexes.pop();
                    if(stackOfIndexes.isEmpty()) {
                        max = Math.max(max, columns[top] * (index));
                    } else {
                        max = Math.max(max, (columns[top] * (index - stackOfIndexes.peek() - 1)));
                    }
                }
            }
            stackOfIndexes.push(index);

            index++;
        }
        while (!stackOfIndexes.isEmpty()) {
            int top = stackOfIndexes.pop();
            if (stackOfIndexes.isEmpty()) {
                max = Math.max(max, columns[top] * (columns.length));
            } else {
                max = Math.max(max, columns[top] * (columns.length - stackOfIndexes.peek() - 1));
            }
        }

//        while(index < columns.length) {
//
//            if(isHistogramIsStillGoingUp.apply(index)) {
//                stackOfIndexes.push(index);
//            } else {
//                while(isHistogramFlatOrFalling.apply(index)) {
//                    int top = stackOfIndexes.pop();
//                    if(stackOfIndexes.isEmpty()) {
//                        max = Math.max(max, columns[top] * (index));
//                    } else {
//                        max = Math.max(max, (columns[top] * (index - stackOfIndexes.peek() - 1)));
//                    }
//                }
//                stackOfIndexes.push(index);
//            }
//            index++;
//        }
//        while (!stackOfIndexes.isEmpty()) {
//            int top = stackOfIndexes.pop();
//            if (stackOfIndexes.isEmpty()) {
//                max = Math.max(max, columns[top] * (columns.length));
//            } else {
//                max = Math.max(max, columns[top] * (columns.length - stackOfIndexes.peek() - 1));
//            }
//        }
        return max;
    }
}

class LargestAreaFinder {
    public int findAreaOfLargestSquare(final int[][] matrix) {
        final int[][] clone = matrix.clone();
        int result = 0;

        for(int r = 1; r < matrix.length; r++) {
            for(int c = 1; c < matrix[r].length; c++) {
                if(matrix[r][c] != 0) {
                    int localMin = 1 + Math.min(clone[r - 1][c - 1], Math.min(clone[r - 1][c], clone[r][c - 1]));
                    clone[r][c] = localMin;
                    if(localMin > result) result = localMin;
                }
            }
        }

        return result;
    }
}

class PartitionLabels {
    public List<String> partition(final String src) {
        Map<Character, Integer> lastIndexOf = new HashMap<>();
        for(int i = 0; i < src.length(); i++) {
            lastIndexOf.put(src.charAt(i), i);
        }

        List<String> result = new ArrayList<>();
        int start = 0;
        int end = 0;
        for(int i = 0; i < src.length(); i++) {
            int current = lastIndexOf.get(src.charAt(i));
            end = Math.max(end, current);
            if(end == i) {
                result.add(src.substring(start, end));
                start = end + 1;

            }
        }
        return result;
    }
}

class QuickSortPartition {
    private static int partition(int[ ] data, int first, int last){
        int low = first - 1;
        int high = last + 1;
        int pivot = data[low];

        while (true) {

            do {
                low++;
            }
            while (data[low] < pivot);

            do {
                high--;
            }
            while (data[high] > pivot);

            if (low < high) {
                int temp = data[low];
                data[low] = data[high];
                data[high] = temp;
            } else {
                return high;
            }
        }

    }

}

class FindMedianInTwoSortedArrays {

    //https://www.youtube.com/watch?v=LPFhl65R7ww&t=1013s
    public double findMedianSortedArraysByTusharRoy(int[] input1, int[] input2) {
        if(input1.length > input2.length) {
            // make input1 the smaller input
            return findMedianSortedArraysByTusharRoy(input2, input1);
        }

        int x = input1.length;
        int y = input2.length;

        int low = 0;
        int high = x;

        while(low <= high) {
            int partitionX = (low + high) / 2;
            int partitionY = (x + y + 1) / 2 - partitionX;

            int maxLeftX = (partitionX == 0) ? Integer.MIN_VALUE : input1[partitionX - 1];
            int minRightX = (partitionX == x) ? Integer.MAX_VALUE : input1[partitionX];

            int maxLeftY = (partitionY == 0) ? Integer.MIN_VALUE : input2[partitionY - 1];
            int minRightY = (partitionY == y) ? Integer.MAX_VALUE : input2[partitionY];

            if(maxLeftX <= minRightY && maxLeftY <= minRightX) {
                if((x + y) % 2 ==0) {
                    return ((double)Math.max(maxLeftX, maxLeftY) + Math.min(minRightX, minRightY)) / 2;
                } else {
                    return Math.max(maxLeftX, maxLeftY);
                }
            } else if(maxLeftX > minRightY) {
                high = partitionY - 1;
            } else {
                low = partitionX + 1;
            }
        }

        throw new IllegalArgumentException();
    }
}

class MockProblemWithProductArray {

    public int[] prodFunc(int[] src) {
        final int total = Arrays.stream(src).reduce(1, (a, b) -> a * b);

        return Arrays.stream(src).map(i -> (total / i)).toArray();
    }

    public int[] prodAll(int[] src) {
        int total = 1;
        for(int i = 0; i < src.length; i++) {
            total *= src[i];
        }

        int[] answer = src.clone();

        for(int i = 0; i < src.length; i++) {
            answer[i] = (total / src[i]);
        }

        return answer;
    }
}

class ProductSuggestions {
    public List<List<String>> suggestedProducts(String[] products, String searchWord) {
        List<List<String>> result = new ArrayList<>();

        Set<String> prods = Stream.of(products).collect(Collectors.toSet());

        for(int i = 1; i <= searchWord.length(); i++) {
            String subStr = searchWord.substring(0, i);
            result.add(prods.stream()
                .filter(prod -> prod.startsWith(subStr))
                .sorted(String::compareTo)
                .limit(3)
                .collect(toList()));
        }

        return result;
    }
}

class TopKFrequentlyMentionedKeywords {
    public List<String> topElement(String[] keyword, String[] review, int k) {
        Map<String, Integer> freqMap = new HashMap<>();

        //TreeMap<Integer, Set<String>> inverseMap = new TreeMap<>(Collections.reverseOrder());
        Set<String> keywords = Stream.of(keyword).map(String::toLowerCase).collect(Collectors.toSet());
        for(String rev : review) {
            Set<String> words = Stream.of(rev.split("\\W")).map(String::toLowerCase).collect(Collectors.toSet());
            for(String word : words) {
                if(keywords.contains(word)) {
                    freqMap.merge(word, 1, Integer::sum);
//                    inverseMap.merge(freqMap.get(word), Collections.singleton(word), (l1, l2) -> {
//                        return Stream.of(l1, l2).flatMap(Collection::stream).collect(Collectors.toSet());
//                    });
                }
            }
        }
        List<String> res = new ArrayList<>(freqMap.keySet());
        Collections.sort(res, (a,b)-> (freqMap.get(a)).equals(freqMap.get(b)) ? a.compareTo(b) : freqMap.get(b) - freqMap.get(a));

        return res.subList(0,k);
        //return new ArrayList<>(inverseMap.values().stream().flatMap(Collection::stream).collect(Collectors.toSet())).subList(0, k);
    }
}

class AllTheWaysHome {
    public int maximumPath(int[][] matrix) {
        int endR = matrix.length - 1;
        int endC = matrix[endR].length - 1;

        int[][] memoization = new int[matrix.length][matrix[0].length];

        for(int r = endR; r >= 0; r--) {
            for(int c = endC; c >= 0; c--) {
                boolean canLookDown = (r + 1) <= endR;
                boolean canLookRight = (c + 1) <= endC;
                if(r == 0 && c == 0) {
                    memoization[0][0] = Math.max(memoization[r + 1][c], memoization[r][c + 1]);
                } else if(canLookDown && canLookRight) {
                    memoization[r][c] = Math.min(matrix[r][c], Math.max(memoization[r + 1][c], memoization[r][c + 1]));
                } else if(canLookDown) {
                    memoization[r][c] = Math.min(matrix[r][c], memoization[r + 1][c]);
                } else if(canLookRight) {
                    memoization[r][c] = Math.min(matrix[r][c], memoization[r][c + 1]);
                } else {
                    memoization[endR][endC] = Integer.MAX_VALUE;
                }
            }
        }
        return memoization[0][0];
    }
}

class CriticalEdges {

    public List<List<Integer>> criticalConnections(int n, List<List<Integer>> connections) {
        @Value
        class Node {
            int id;
            List<Node> neighbors = new ArrayList<>();

            @Override
            public boolean equals(final Object other) {
                return other instanceof Node && this.id == ((Node)other).id;
            }
        }

        val graph = new HashMap<Integer, Node>();
        for(val edge : connections) {
            val targetId = edge.get(0);
            val neighborId = edge.get(1);
            Node alpha = graph.getOrDefault(targetId, new Node(targetId));
            Node beta = graph.getOrDefault(neighborId, new Node(neighborId));
            alpha.neighbors.add(beta);
            beta.neighbors.add(alpha);
            graph.put(targetId, alpha);
            graph.put(neighborId, beta);
        }

        class DFS {
            private void dfs(final Node root, final Set<Integer> trail) {
                for(val node : root.neighbors) {
                    if(!trail.contains(node.id)) {
                        trail.add(node.id);
                        dfs(node, trail);
                    }
                }
            }
        }

        val dfs = new DFS();
        List<List<Integer>> criticals = new ArrayList<>();

        for(val node : graph.values()) {
            int contacts = node.neighbors.size() - 1;
            for(int i = 0; i <= contacts; i++) {
                Node oldNeighbor = node.neighbors.remove(i);
                val newTrailRecord = new HashSet<Integer>();
                dfs.dfs(node, newTrailRecord);
                if(newTrailRecord.size() != graph.size()) {
                    List<Integer> newEntry = asList(Math.min(node.id, oldNeighbor.id), Math.max(node.id, oldNeighbor.id));
                    if(!criticals.contains(newEntry)) criticals.add(newEntry);
                }
                node.neighbors.add(oldNeighbor);
            }
        }
        return criticals;
    }
}

@Data
class TreeNode {
    final int val;
    TreeNode left;
    TreeNode right;
    TreeNode(int x ) {
        val = x;
    }

    TreeNode(int x, TreeNode left, TreeNode right) {
        this(x);
        this.left = left;
        this.right = right;
    }

    public List<TreeNode> getChildren() {
        return asList(left, right);
    }

    @Override
    public boolean equals(final Object other) {
        return other instanceof TreeNode && this.val == ((TreeNode)other).val;
    }
}

class SubtreeOfAnotherTree {

    public void run() {
        val one = new TreeNode(1);
        val two = new TreeNode(2);
        val four = new TreeNode(4, one, two);
        val five = new TreeNode(5);
        val three = new TreeNode(3, four, five);

        val one1 = new TreeNode(1);
        val two1 = new TreeNode(2);
        val four1 = new TreeNode(4, one1, two1);

        val res = isSubtree(three, four1);

        System.out.println("######################## 1 " + res);

        val zero2 = new TreeNode(0);
        val one2 = new TreeNode(1);
        val two2 = new TreeNode(2, zero2, null);
        val four2 = new TreeNode(4, one2, two2);
        val five2 = new TreeNode(5);
        val three2 = new TreeNode(3, four2, five2);

        val res2 = isSubtree(three2, four1);

        System.out.println("####################### 2 " + res2);
    }

    public boolean isSubtree(TreeNode s, TreeNode t) {
        if(s == null && t == null) return true;
        if(s == null || t == null) return false;
        if(s.val == t.val && isSubtree(s.left, t.left) && isSubtree(s.right, t.right)) {
            return true;
        } else {
            return isSubtree(s.right, t) || isSubtree(s.left, t);
        }
    }
}

class TreasureIslandTwo {
    public int shortestPath(char[][] islands) {
        final List<int[]> startingSpots = new ArrayList<>();
        for(int i = 0; i < islands.length; i++) {
            for(int j = 0; j < islands[i].length; j++) {
                if(islands[i][j] == 'S') startingSpots.add(new int[] {i,j});
            }
        }

        List<Integer> numOfSteps = new ArrayList<>();

        BiFunction<int[], char[][], Boolean> canEnter = (int[] coords, char[][] map) -> {
            int row = coords[0];
            int col = coords[1];
            return row >= 0 && row < map.length &&
                    col >= 0 && col < map[0].length &&
                    map[row][col] != 'D';
        };

        final int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

        for(int[] spot : startingSpots) {
            Queue<int[]> queue = new LinkedList<>();
            queue.offer(spot);
            char[][] mapCopy = Arrays.stream(islands).map(char[]::clone).toArray(char[][]::new);
            mapCopy[spot[0]][spot[1]] = 'D';
            int steps = 0;
            while(!queue.isEmpty()) {
                int size = queue.size();
                for(int i = 0; i < size; i++) {
                    int[] coords = queue.poll();
                    int row = coords[0];
                    int col = coords[1];
                    if(islands[row][col] == 'X') {
                        numOfSteps.add(steps);
                        break;
                    }
                    for(int[] dir : dirs) {
                        int newRow = row + dir[0];
                        int newCol = col + dir[1];
                        int[] nextStep = {newRow, newCol};
                        if(canEnter.apply(nextStep, mapCopy)) {
                            queue.offer(nextStep);
                            mapCopy[nextStep[0]][nextStep[1]] = 'D';
                        }
                    }
                }
                steps++;
            }
        }
        return java.util.Collections.min(numOfSteps);
    }

    public int shortestPathTakeTwo(char[][] islands) {
        final List<int[]> startingSpots = new ArrayList<>();
        for(int i = 0; i < islands.length; i++) {
            for(int j = 0; j < islands[i].length; j++) {
                if(islands[i][j] == 'S') startingSpots.add(new int[] {i,j});
            }
        }

        List<Integer> numOfSteps = new ArrayList<>();

        Function<int[], Boolean> canEnter = (int[] coords) -> {
            return coords[0] >= 0 && coords[0] < islands.length &&
                    coords[1] >= 0 && coords[1] < islands[0].length &&
                    islands[coords[0]][coords[1]] != 'D';
        };

        final int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

        for(int[] spot : startingSpots) {
            Queue<int[]> queue = new LinkedList<>();
            queue.offer(spot);
            char[][] mapCopy = Arrays.stream(islands).map(char[]::clone).toArray(char[][]::new);
            mapCopy[spot[0]][spot[1]] = 'D';
            int steps = 0;
            while(!queue.isEmpty()) {
                steps++;
                int[] coords = queue.poll();
                int row = coords[0];
                int col = coords[1];
                if(islands[row][col] == 'X') {
                    numOfSteps.add(steps);
                    break;
                }
                for(int[] dir : dirs) {
                    int newRow = row + dir[0];
                    int newCol = col + dir[1];
                    int[] nextStep = {newRow, newCol};
                    if(canEnter.apply(nextStep)) {
                        queue.offer(nextStep);
                        mapCopy[nextStep[0]][nextStep[1]] = 'D';
                    }
                }
            }
        }
        return java.util.Collections.min(numOfSteps);
    }

    public int shortestPathMyTry(char[][] islands) {
        if(islands == null || islands.length < 1 || islands[0].length < 1) return -1;

        Queue<int[]> queue = new ArrayDeque<>();
        for(int r = 0; r < islands.length; r++) {
            for(int c = 0; c < islands[r].length; c++) {
                if(islands[r][c] == 'S') {
                    queue.offer(new int[] {r, c});
                    islands[r][c] = 'D';
                }
            }
        }

        Function<int[], Boolean> canEnter = (coord) -> {
            int r = coord[0];
            int c = coord[1];
            return r >= 0 && r < islands.length &&
                    c >= 0 && c < islands[r].length &&
                    islands[r][c] != 'D';
        };

        final int[][] dirs = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

        int steps = 0;

        while(!queue.isEmpty()) {
            int size = queue.size();
            for(int i = 0; i < size; i++) {
                int[] next = queue.poll();
                int r = next[0];
                int c = next[1];
                if(islands[r][c] == 'X') {
                    return steps;
                }
                for(int[] dir : dirs) {
                    int newR = r + dir[0];
                    int newC = c + dir[1];
                    int[] newCell = new int[] {newR, newC};
                    if(canEnter.apply(newCell)) {
                        queue.offer(newCell);
                        islands[newR][newC] = 'D';
                    }
                }
            }
            steps++;
        }

        return -1;
    }

    public int shortestPathSomeoneElse(char[][] islands){
        if(islands.length == 0 || islands[0].length == 0) return -1;
        int R = islands.length, C = islands[0].length;
        Queue<int[]> queue = new LinkedList<>();
        int steps = 1;
        // add all sources to queue and set 'visited'.
        for(int i = 0; i < R; ++i){
            for(int j = 0; j < C; ++j){
                if(islands[i][j] == 'S'){
                    queue.add(new int[]{i, j}); islands[i][j] = 'D';
                }
            }
        }

        final int[][] dirs = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

        while(!queue.isEmpty()){
            int size = queue.size();
            for(int i = 0; i < size; ++i){
                int[] pos = queue.poll();
                for(int[] dir: dirs){
                    int x = pos[0] + dir[0], y = pos[1] + dir[1];
                    if(x < 0 || x >= R || y < 0 || y >= C || islands[x][y] == 'D') continue;
                    if(islands[x][y] == 'X') return steps;
                    queue.add(new int[]{x, y});
                    islands[x][y] = 'D';
                }
            }
            ++steps;
        }
        return -1;
    }
}

/**
 * find optimal way of adding two numbers
 * https://leetcode.com/discuss/interview-question/373202
 */
class OptimalUtilization {

//    public List<int[]> solution(final List<int[]> a, final List<int[]> b, final int target) {
//        Collections.sort(a, (i, j) -> i[1] - j[1]);
//        Collections.sort(b, (i, j) -> i[1] - j[1]);
//
//        final TreeMap<Integer, List<int[]>> treeMap = new TreeMap<>();
//
//        for(int i = 0; i < a.size(); i++) {
//            for(int j = b.size() - 1; j >= 0; j--) {
//                final int sum = a.get(i)[1] + b.get(j)[1];
//                if(sum > target) {
//                    while(b.get(j) == b.get(j - 1)) j--;
//                }
//                List<int[]> vals = treeMap.getOrDefault(sum, new ArrayList<>());
//                vals.add(new int[]{a.get(i)[0], b.get(j)[0]});
//                treeMap.put(sum, vals);
//                if(sum < target && treeMap.floorEntry(target) != null)
//
//            }
//        }
//        return treeMap.ceilingEntry()
//    }
    public List<int[]> solution(final List<int[]> a, final List<int[]> b, final int target) {
        Collections.sort(a, (i, j) -> i[1] - j[1]);
        Collections.sort(b, (i, j) -> i[1] - j[1]);

        int j = b.size() - 1;

        final TreeMap<Integer, List<int[]>> treeMap = new TreeMap<>();

        for(int i = 0; i < a.size(); i++) {
            int sum = a.get(i)[1] + b.get(j)[1];
            while(sum > target && j > 0) {
                sum = a.get(i)[1] + b.get(--j)[1];
            }
            if(sum <= target) {
                if(treeMap.headMap(target, true).size() > 2) return treeMap.lastEntry().getValue();
                List<int[]> entry = treeMap.getOrDefault(sum, new ArrayList<>());
                entry.add(new int[]{a.get(i)[0], b.get(j)[0]});
                treeMap.put(sum, entry);
            }
        }

        return treeMap.lastEntry().getValue();
    }
}

class TopologicalSort {
    public void run() {

    }

    List<TreeNode> topoSortDFS(final List<TreeNode> nodes) {
        final Stack<TreeNode> stack = new Stack<>();
        final Set<Integer> visited = new HashSet<>();

        final class Recurse {
            private void dfs(final TreeNode treeNode) {
                visited.add(treeNode.val);
                for(final TreeNode t : treeNode.getChildren()) {
                    if(!visited.contains(t.val)) {
                        dfs(t);
                    }
                }
                stack.push(treeNode);
            }
        }

        final Recurse recurse = new Recurse();

        for(final TreeNode t : nodes) {
            if(!visited.contains(t.val)) {
                recurse.dfs(t);
            }
        }

        return new ArrayList<>(stack);
    }
}

class CourseSchedule {

    public void run() {
        System.out.println(canFinishImperative(3, new int[][] {{0,2},{1,2},{2,0}}));
    }

    public boolean canFinishColorSets(final int numCourses, final int[][] prerequisites) {
        Set<Integer> whiteSet = new HashSet<>();
        Set<Integer> greySet = new HashSet<>();
        Set<Integer> blackSet = new HashSet<>();

        Map<Integer, List<Integer>> neighbors = new HashMap<>();

        for(int[] course : prerequisites) {
            whiteSet.add(course[0]);
            whiteSet.add(course[1]);
            List<Integer> arg = neighbors.getOrDefault(course[0], new ArrayList<>());
            arg.add(course[1]);
            neighbors.put(course[0], arg);
        }

        while(whiteSet.size() > 0) {
            Integer next = whiteSet.iterator().next();
            if(dfs(next, whiteSet, greySet, blackSet, neighbors)) {
                return true;
            }
        }
        return false;
    }

    private boolean dfs(Integer next, Set<Integer> white, Set<Integer> grey, Set<Integer> black, Map<Integer, List<Integer>> neighbors) {
        moveVertex(next, white, grey);

        for(Integer neighbor : neighbors.get(next)) {
            if(black.contains(neighbor)) continue;

            if(grey.contains(neighbor)) return true;

            if(dfs(neighbor, white, grey, black, neighbors)) {
                return true;
            }
        }
        moveVertex(next, grey, black);
        return false;
    }

    private void moveVertex(Integer next, Set<Integer> src, Set<Integer> des) {
        src.remove(next);
        des.add(next);
    }

    public boolean canFinishImperative(final int numCourses, final int[][] prerequisites) {
        class DisjointSet {
            final List<Integer> classes;

            DisjointSet(final Integer clazz) {
                this.classes = new ArrayList<>();
                this.classes.add(clazz);
            }
        }

        Map<Integer, DisjointSet> map = new HashMap<>();

        for(int[] course : prerequisites) {
            DisjointSet newSetA = map.getOrDefault(course[0], new DisjointSet(course[0]));
            map.put(course[0], newSetA);
            DisjointSet newSetB = map.getOrDefault(course[1], new DisjointSet(course[1]));
            map.put(course[1], newSetB);
        }

        for(int[] course : prerequisites) {
            DisjointSet a = map.get(course[0]);
            DisjointSet b = map.get(course[1]);

            if (a == b) return false;

            a.classes.addAll(b.classes);

            b.classes.forEach(c -> map.put(c, a));
        }
        return true;
    }

    public boolean canFinish(final int numCourses, final int[][] prerequisites) {
        if(prerequisites.length < 1) return true;
        class Node {
            final int id;
            final Set<Node> prereq;

            Node(final int id) {
                this.id = id;
                this.prereq = new HashSet<>();
            }

            public void addPrereq(final Node other) {
                assert this.id != other.id;
                this.prereq.add(other);
            }

            @Override
            public boolean equals(final Object o) {
                if (this == o) return true;
                if (o == null || getClass() != o.getClass()) return false;
                final Node node = (Node) o;
                return id == node.id;
            }

            @Override
            public int hashCode() {
                return Objects.hash(id);
            }
        }

        final Map<Integer, Node> knownCourses = new HashMap<>();
        final java.util.function.Function<Integer, Node> nodeCreator = (final Integer id) -> {
            if(knownCourses.containsKey(id)) return knownCourses.get(id);
            final Node newNode = new Node(id);
            knownCourses.put(id, newNode);
            return newNode;
        };

        final Map<Integer, Node> graph = new HashMap<>();
        for(final int[] course : prerequisites) {
            final Node currentCourse = graph.getOrDefault(course[0], nodeCreator.apply(course[0]));
            final Node dependency = graph.getOrDefault(course[1], nodeCreator.apply(course[1]));

            currentCourse.addPrereq(dependency);
            graph.put(course[0], currentCourse);
        }

        final List<Node> nodes = new ArrayList<>(graph.values());
        nodes.sort(Comparator.comparingInt(a -> a.prereq.size()));

        class Recurse {
            private boolean hasCycleRecursive(final Node currentNode, final Set<Integer> visited, final Set<Integer> beingVisited) {
                beingVisited.add(currentNode.id);
                visited.add(currentNode.id);
                for(final Node child : currentNode.prereq) {
                    if(beingVisited.contains(child.id)) return true;
                    if(!visited.contains(child.id)) {
                        if(hasCycleRecursive(child, visited, beingVisited)) {
                            return true;
                        }
                    }
                }
                beingVisited.remove(currentNode.id);
                return false;
            }
        }
        return !new Recurse().hasCycleRecursive(nodes.get(0), new HashSet<>(), new HashSet<>());
    }
}

class FourSum {

    public List<List<Integer>> fourSum(int[] nums, int target) {
        Arrays.sort(nums);
        List<List<Integer>> list = new ArrayList<>();
        if (nums.length > 3) {
            for (int i = 0; i < nums.length; i++) {
                for (int j = nums.length - 1; j > i + 1; j--) {
                    int startIndex = i + 1, endIndex = j - 1;
                    while (startIndex < endIndex) {
                        int sum = nums[i] + nums[j] + nums[startIndex] + nums[endIndex];
                        while (sum < target && startIndex < endIndex) {
                            ++startIndex;
                            sum = nums[i] + nums[j] + nums[startIndex] + nums[endIndex];
                        }
                        while (sum > target && endIndex > startIndex) {
                            --endIndex;
                            sum = nums[i] + nums[j] + nums[startIndex] + nums[endIndex];
                        }
                        if (sum == target && startIndex != endIndex) {
                            List integers = new ArrayList<>();
                            integers.add(nums[i]);
                            integers.add(nums[j]);
                            integers.add(nums[startIndex]);
                            integers.add(nums[endIndex]);
                            if (!list.contains(integers)) {
                                list.add(integers);
                            }
                            ++startIndex;
                            --endIndex;
                        }
                    }
                }
            }
            return list;
        }
        return new ArrayList<>();

    }
}

class GroupAnagrams {

    public List<List<String>> groupAnagrams(final String[] strs) {
        final Map<String, List<String>> result = new HashMap<>();
        for(final String str : strs) {
            final char[] chars = str.toCharArray();
            java.util.Arrays.sort(chars);
            final String alphabetized = new String(chars);
            result.getOrDefault(alphabetized, new ArrayList<>()).add(str);
        }
        return new ArrayList<>(result.values());
    }
}

class DNASequences {
    public List<String> findRepeatedDnaSequences(final String s) {
        if(s.length() < 10) return new ArrayList<>();

        int i = 0;
        int j = 9;

        final Set<String> filter = new HashSet<>();
        final Set<String> result = new HashSet<>();
        while(j < s.length()) {
            final String sub = s.substring(i++, j++);
            if(filter.contains(sub)) {
                result.add(sub);
            }
            filter.add(sub);
        }
        return new ArrayList<>(result);
    }
}

class GreaterSumTree {
    private class TreeNode {
        int val;
        TreeNode left;
        TreeNode right;
        TreeNode(int x) { val = x; }
    }

//    public TreeNode bstToGst(final TreeNode root) {
//        final Stack<TreeNode> stack = new Stack<>();
//        stack.push(root);
//
//        while(!stack.empty()) {
//            final TreeNode next = stack.pop();
//            if(next.right != null) {
//                stack.push(next.right);
//            }
//
//        }
//    }

    public TreeNode bstToGst2(final TreeNode root) {
        Stack<TreeNode> reversePreOrder = new Stack<>();
        reversePreOrder(root, reversePreOrder);
        return root;
    }

    private void reversePreOrder(TreeNode root, Stack<TreeNode> reversePreOrder){
        if (root == null) return;
        reversePreOrder(root.right, reversePreOrder);

        if (!reversePreOrder.empty()) root.val += reversePreOrder.peek().val;
        reversePreOrder.push(root);
        reversePreOrder(root.left, reversePreOrder);

    }

}

class CompleteCircle {
    public int canCompleteCircuit(final int[] gas, final int[] cost) {
        int deficit = 0;
        int positive = 0;
        for(int i = 0; i < gas.length; i++) {
            deficit += (gas[i] - cost[i]);
            if(deficit > 0) positive = (i - 1);
        }
        return deficit > 0 ? positive : -1;
    }
}

class CriticalNodes {

    public List<Integer> findCriticalNodesInGraph(final int[][] edges) {
        @Value
        class Node {
            int id;
            List<Node> neighbors = new ArrayList<>();

            @Override
            public boolean equals(final Object other) {
                return other instanceof Node && this.id == ((Node)other).id;
            }
        }

        val graph = new HashMap<Integer, Node>();
        for(val edge : edges) {
            val targetId = edge[0];
            val neighborId = edge[1];
            val alpha = graph.getOrDefault(targetId, new Node(targetId));
            val beta = graph.getOrDefault(neighborId, new Node(neighborId));
            alpha.neighbors.add(beta);
            beta.neighbors.add(alpha);
            graph.put(targetId, alpha);
            graph.put(neighborId, beta);
        }

        class DFS {
            private void dfs(final Node root, final Node neighbor, final Set<Integer> trail) {
                for(val node : neighbor.neighbors) {
                    if(!trail.contains(node.id) && (node.id != root.id)) {
                        trail.add(node.id);
                        dfs(root, node, trail);
                    }
                }
            }
        }

        val dfs = new DFS();
        val criticals = new ArrayList<Integer>();

        for(val node : graph.values()) {
            val trails = new HashSet<Set<Integer>>();
            for(val neighbor : node.neighbors) {
                val newTrailRecord = new HashSet<Integer>();
                dfs.dfs(node, neighbor, newTrailRecord);
                trails.add(newTrailRecord);
            }
            if(!trails.isEmpty()) criticals.add(node.id);
        }
        return criticals;
    }
}

class TreasureIsland {

    public int numberOfStepsToTreasure(final char[][] map) {
        val nextStepQueue = new LinkedList<int[]>();
        nextStepQueue.offer(new int[] {0,0});
        map[0][0] = 'D';

        final Function<int[], Boolean> canEnter = (final int[] cellOfMap) -> {
            val row = cellOfMap[0];
            val col = cellOfMap[1];
            return row >= 0 && row < map.length &&
                   col >= 0 && col < map[row].length &&
                   map[row][col] != 'D';
        };

        val dirs = new int[][] {{1,0},{-1,0},{0,1},{0,-1}};

        int steps = 0;

        while(!nextStepQueue.isEmpty()) {
            steps++;
            val nextStep = nextStepQueue.poll();
            val row = nextStep[0];
            val col = nextStep[1];
            if(map[row][col] == 'X') return steps;
            for(val dir : dirs) {
                val newStep = new int[] {(row + dir[0]), (col + dir[1])};
                if(canEnter.apply(newStep)) {
                    nextStepQueue.offer(newStep);
                    map[newStep[0]][newStep[1]] = 'D';
                }
            }
        }
        return steps > 0 ? steps : -1;
    }

}

class ZombiesInAMatrix {

    public int hoursTilTotalInfection(final int[][] grid) {
        val alphaQueue = new LinkedList<int[]>();
        val betaQueue = new LinkedList<int[]>();

        for(int r = 0; r < grid.length; r++) {
            for(int c = 0; c < grid[r].length; c++) {
                if(grid[r][c] == 1) alphaQueue.offer(new int[] {r,c});
            }
        }

        final Function<int[], Boolean> canEnter = (final int[] cellOfMatrix) -> {
            val row = cellOfMatrix[0];
            val col = cellOfMatrix[1];
            return row >= 0 && row < grid.length &&
                   col >= 0 && col < grid[row].length &&
                   grid[row][col] != 1;
        };

        final Function<Queue<int[]>, Queue<int[]>> getInactiveQueue =
            (final Queue<int[]> active) -> active.equals(alphaQueue) ? betaQueue : alphaQueue;

        val dirs = new int[][] {{1,0},{-1,0},{0,1},{0,-1}};

        int hours = 0;

        Queue<int[]> activeQueue = alphaQueue;
        while(!activeQueue.isEmpty()) {
            val inactiveQueue = getInactiveQueue.apply(activeQueue);
            val nextCell = activeQueue.poll();
            for(val dir : dirs) {
                val newInfection = new int[] {(nextCell[0] + dir[0]), (nextCell[1] + dir[1])};
                if(canEnter.apply(newInfection)) {
                    inactiveQueue.offer(newInfection);
                    grid[newInfection[0]][newInfection[1]] = 1;
                }
            }
            if(activeQueue.isEmpty()) {
                activeQueue = inactiveQueue;
                if(!alphaQueue.isEmpty() || !betaQueue.isEmpty()) hours++;
            }
        }
        return hours;
    }
}

class TopKFrequentWords {
    public List<String> topKFrequent(final String[] words, final int k) {
        val frequencyMap = new HashMap<String, Integer>();
        for(val word : words) {
            frequencyMap.merge(word, 1, Integer::sum);
        }

        val result = new ArrayList<String>(frequencyMap.keySet());
        result.sort((final String word1, final String word2) ->
            frequencyMap.get(word1).equals(frequencyMap.get(word2)) ?
                word1.compareTo(word2) :
                frequencyMap.get(word2) - frequencyMap.get(word1));

        return result.subList(0, k);
    }
}

class ReorderDataLogFiles {
    public String[] reorderLogFiles(final String[] logs) {
        final String nums = "0123456789";
        final List<String> numLogs = new ArrayList<>();
        final PriorityQueue<String> letterLogs = new PriorityQueue<>((s1, s2) -> {
            final int res = s1.substring(5, s1.length() - 1).compareTo(s2.substring(5, s2.length() - 1));
            if(res == 0) {
                return s1.substring(0, 5).compareTo(s2.substring(0, 5));
            } else {
                return res;
            }
        });

        for(final String log : logs) {
            final boolean isLetterLog = nums.indexOf(log.charAt(5)) == -1;
            if(isLetterLog) {
                letterLogs.offer(log);
            } else {
                numLogs.add(log);
            }
        }
        for(int i = 0; !letterLogs.isEmpty(); i++) {
            numLogs.add(i, letterLogs.poll());
        }
        return numLogs.toArray(String[]::new);
    }
}

class MinCostToConnectRopes {
    public int minCost(final List<Integer> ropes) {
        final Queue<Integer> queue = new PriorityQueue<>(ropes);
        int totalCost = 0;
        while(queue.size() > 1) {
            final int cost = queue.poll() + queue.poll();
            queue.add(cost);
            totalCost += cost;
        }
        return totalCost;
    }
}

class Fibonnaci {

    public void run() {
        val res = OofNTime(10);

        System.out.println(res);
    }

    public long OofNTime(final int target) {
        if(target == 0) return 0;
        if(target == 1) return 1;

        int[] arr = new int[] {0, 1};

        for(int count = 0; count < target; count++) {

            int temp = arr[0] + arr[1];
            arr[0] = arr[1];
            arr[1] = temp;
        }

        return arr[1];
    }
}

class FindPairWithGivenSum {
    public List<Integer> findPair(List<Integer> nums, int target) {
        target -= 30;
        Map<Integer, List<Integer>> complementAndIndex = new HashMap<>();
        for(int i = nums.size() -1; i >= 0; i--) {
            int complement = target - nums.get(i);
            if(complementAndIndex.containsKey(target - complement)) {
                return asList(i, complementAndIndex.get(target - complement).get(0));
            } else {
                complementAndIndex.merge(complement, asList(i), (l1, l2) -> {
                    return Stream.of(l1, l2).flatMap(Collection::stream).collect(toList());
                });
            }
        }
        return emptyList();
    }
}

/**
 * count the number of separate islands
 */
class CountingClusters {
    public int numIslands(final char[][] grid) {
        final boolean[][] visited = new boolean[grid.length][grid[0].length];

        class DFS {
            public void dfs(final int r, final int c) {
                if(r >= 0 && r < grid.length && c >= 0 && c < grid[0].length && grid[r][c] == '1' && !visited[r][c]) {
                    visited[r][c] = true;
                    dfs(r + 1, c);
                    dfs(r - 1, c);
                    dfs(r, c + 1);
                    dfs(r, c - 1);
                }
            }
        }

        int islandCount = 0;
        final DFS dfs = new DFS();
        for(int r = 0; r < grid.length; r++) {
            for(int c = 0; c < grid[r].length; c++) {
                if(!visited[r][c] && grid[r][c] == '1') islandCount++;
                dfs.dfs(r, c);
            }
        }

        return islandCount;
    }
}
