package dsa.practice;

import java.util.Arrays;

public class LongestNonDecreasingSubsequence {

    public static void main(String[] args) {
        System.out.println(longestNonDecSubseq(new int[] {-1, 3, 4, 5, 2, 2, 2, 2}));
    }

    // https://www.youtube.com/watch?v=fV-TF4OvZpk
    public static int longestNonDecSubseq(final int[] seq) {
        if(seq.length == 0) return 0;
        if(seq.length == 1) return 1;

        final int[] memoization = new int[seq.length];
        Arrays.fill(memoization, 1);

        int max = 0;
        int left = 0;
        int right = 1;
        while(left < seq.length - 1 && right < seq.length) {

            if(seq[left] <= seq[right]) {
                final int newSeqLength = memoization[left] + 1;
                if(newSeqLength > memoization[right]) {
                    memoization[right] = newSeqLength;
                }
            }
            
            left++;

            if(memoization[right] > max) {
                max = memoization[right];
            }

            if(left == right) {
                left = 0;
                right++;
            }
        }

        System.out.println(Arrays.toString(memoization));
        return max;
    }
}
