package dsa.practice;

import java.util.Arrays;
import java.util.function.Function;

public class StringManipReview {

}

class ReverseString {
    public String reverseStringIterative(final String str) {
        final StringBuilder sb = new StringBuilder();
        for(int i = str.length() - 1; i >= 0; i--) {
            sb.append(str.charAt(i));
        }
        return sb.toString();
    }

    public String reverseStringRecursive(final String str) {
        class Recurse {
            private String reverseRecursive(final String source, final StringBuilder drain) {
                if(source.isEmpty()) return drain.toString();
                return reverseRecursive(source.substring(0, source.length() - 2), drain.append(source.charAt(source.length() - 1)));
            }
        }
        return new Recurse().reverseRecursive(str, new StringBuilder());
    }
}

class FindFirstNonRepeatedCharacter {
    public char findFirstNonRepeatedCharacter(final String str) {
        final char[] chars = str.toCharArray();
        Arrays.sort(chars);
        for(int i = 0; i < chars.length; i++) {
            if(i != chars.length - 1 && (chars[i] != chars[i + 1])) {
                return chars[i];
            }
        }
        return 0;
    }
}

class PrintDuplicteCharacters {
    public void printDuplicates(final String str) {
        final char[] chars = str.toCharArray();
        Arrays.sort(chars);
        final String sorted = new String(chars);
        final StringBuilder sb = new StringBuilder();
        for(int i = 0; i < sorted.length(); i++) {
            final char current = sorted.charAt(i);
            if((i != sorted.length() - 1) && current == sorted.charAt(i + 1)) {
                sb.append(current);
            }
        }
        System.out.println(sb.toString());
    }

}

class Anagrams {
    public boolean areAnagrams(final String a, final String b) {
        Function<String, String> returnWordSortedByLetters = (final String str) -> {
            final char[] result = str.toLowerCase().replaceAll("[^a-z]", "").toCharArray();
            Arrays.sort(result);
            return new String(result);
        };

        final String aNew = returnWordSortedByLetters.apply(a);
        final String bNew = returnWordSortedByLetters.apply(b);

        return aNew.equals(bNew);
    }
}
